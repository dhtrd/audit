# PRE-AUDIT OS — دليل التشغيل والنشر

نظام Next.js 14 (واجهة + API في تطبيق واحد) يعتمد قاعدة بيانات **SQLite عبر `node:sqlite`**.
لذلك متطلبات التشغيل بسيطة لكن لها شرطان أساسيان:

1. **Node.js 22.5 أو أحدث** (مطلوب لوحدة `node:sqlite` المدمجة).
2. **قرص دائم (persistent volume)** لملف قاعدة البيانات — لأن البيانات ملف واحد على القرص، وليست خدمة خارجية.

> مهم: هذا **لا يعمل** على بيئات serverless عديمة الحالة (مثل Vercel Functions/Edge) لأن ملف SQLite يُمحى بين الاستدعاءات. انشره كخادم Node دائم (VPS، Docker، Railway/Render/Fly.io مع volume، أو أي VM).

---

## 1) التجربة محليًا (سريع)

```bash
npm install
npm run db:seed          # ينشئ أول مدير — اطبع المخرجات لرؤية كلمة المرور
npm run dev              # بيئة تطوير على http://localhost:3000
```

الدخول الافتراضي: `admin@company.local` / `ChangeMe123!` (غيّرها فورًا من صفحة "حسابي").

عيّنات جاهزة للتجربة في مجلد `samples/` (استيراد → رفع ملف). اقرأ `samples/README.md`.

## 2) التشغيل الإنتاجي (بدون Docker)

```bash
# 1) متغيرات البيئة الإلزامية (لا تستخدم القيم الافتراضية في الإنتاج)
export NODE_ENV=production
export JWT_SECRET="$(openssl rand -hex 32)"     # سرّ قوي 32 بايت على الأقل — إلزامي
export DATABASE_FILE="/var/lib/preauditos/dev.db"  # مسار على قرص دائم
export UPLOAD_DIR="/var/lib/preauditos/uploads"    # الأدلة والملفات المرفوعة
mkdir -p /var/lib/preauditos/uploads

# 2) أول مدير (مرة واحدة) — بقيم من عندك
SEED_ADMIN_EMAIL="you@company.com" SEED_ADMIN_PASSWORD="STRONG-Pass-123" SEED_ADMIN_NAME="اسمك" npm run db:seed

# 3) البناء والتشغيل
npm ci
npm run build
npm start                # يستمع على المنفذ 3000 (غيّره بـ PORT=8080 npm start)
```

يُفضَّل تشغيله خلف مدير عمليات (systemd أو pm2) وخلف وكيل عكسي (Nginx/Caddy) يوفّر **HTTPS**
(كوكيز الجلسة تُعلَّم Secure تلقائيًا في الإنتاج، فتحتاج HTTPS ليعمل الدخول).

### مثال systemd
```ini
[Service]
WorkingDirectory=/opt/pre-audit-os
Environment=NODE_ENV=production
Environment=JWT_SECRET=<سرّك>
Environment=DATABASE_FILE=/var/lib/preauditos/dev.db
Environment=UPLOAD_DIR=/var/lib/preauditos/uploads
ExecStart=/usr/bin/npm start
Restart=always
```

## 3) التشغيل عبر Docker (موصى به)

```bash
docker build -t pre-audit-os .

docker run -d --name preauditos -p 3000:3000 \
  -e JWT_SECRET="$(openssl rand -hex 32)" \
  -e DATABASE_FILE=/data/dev.db \
  -e UPLOAD_DIR=/data/uploads \
  -v preauditos_data:/data \
  pre-audit-os

# أول مدير (مرة واحدة داخل الحاوية)
docker exec -e SEED_ADMIN_EMAIL=you@company.com -e SEED_ADMIN_PASSWORD='STRONG-Pass-123' \
  -e DATABASE_FILE=/data/dev.db preauditos npm run db:seed
```

الـ `-v preauditos_data:/data` هو القرص الدائم — يحفظ قاعدة البيانات والأدلة عبر إعادة التشغيل/التحديث.

## 4) قائمة تحقق قبل الرفع (Production checklist)

- [ ] Node 22.5+ على خادم الإنتاج.
- [ ] `JWT_SECRET` سرّ قوي وفريد (ليس القيمة الافتراضية) — تغييره يُخرج كل المستخدمين.
- [ ] `DATABASE_FILE` و`UPLOAD_DIR` على **قرص دائم** يُؤخذ له نسخ احتياطي.
- [ ] HTTPS مُفعّل (وكيل عكسي) — ضروري لكوكيز الجلسة الآمنة.
- [ ] تغيير كلمة مرور المدير الأول بعد الدخول.
- [ ] نسخ احتياطي دوري لملف قاعدة البيانات (`DATABASE_FILE`) ومجلد `UPLOAD_DIR`.
- [ ] (اختياري) استدعاء `GET /api/audit-pack?companyId=...` من مجدول خارجي (cron) إن أردت تصديرًا دوريًا.

## 5) النسخ الاحتياطي والاستعادة

كل الحالة في مكانين فقط:
- ملف قاعدة البيانات: `$DATABASE_FILE` (افتراضيًا `data/dev.db`).
- مجلد الملفات المرفوعة (الاستيرادات والأدلة): `$UPLOAD_DIR` (افتراضيًا `data/uploads`).

انسخهما معًا (مثلًا `tar czf backup.tgz $DATABASE_FILE $UPLOAD_DIR`) دوريًا. الاستعادة = إرجاعهما مكانهما.

## 6) الانتقال إلى PostgreSQL لاحقًا (عند الحاجة لتعدد مستخدمين متزامنين بكثافة)

كما في README: استبدل محتوى `src/lib/db.ts` بعميل `pg`/`postgres` يُصدِّر نفس دوال
`prepare().get()/.all()/.run()` — بقية التطبيق (repo/الخدمات/المسارات) لا يتغيّر.

## ملاحظات أمنية مطبّقة

- كلمات المرور: bcrypt، ولا تُخزَّن نصًّا في أي مكان (ولا في سجل التدقيق).
- الجلسات: JWT HS256 في كوكي HttpOnly + SameSite=Lax + Secure(إنتاج)، مع **إبطال فوري** عند
  تغيير الدور/التعطيل/كلمة المرور (Phase 11).
- صلاحيات ثلاث: مدير/منفّذ/مراجع مع فصل مهام (الاعتماد للمدير فقط).
- سجل تدقيق غير قابل للحذف لكل عملية حسّاسة.
- تسوية إلزامية غير قابلة للتجاوز في الاستيراد (BLOCKED)، وسلامة التقرير عبر بصمة SHA-256.
